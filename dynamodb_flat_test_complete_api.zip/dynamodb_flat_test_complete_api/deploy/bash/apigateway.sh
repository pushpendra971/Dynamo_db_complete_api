#!/bin/bash
set -e
# apiid="ofea0n70ae"
# apiid="s9owegovd8"
apiid=$2
echo $1

# aws apigateway put-rest-api --rest-api-id $apiid --mode $1 --body ../../cloudformation/swagger.json
aws apigateway put-rest-api --rest-api-id $apiid  --mode $1 --body 'file:////home/code5/src/air3-backend/cloudformation/swagger.json'
