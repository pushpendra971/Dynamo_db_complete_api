
getfilename(){
	somevar="$(basename $1 .zip)"
}

cd src

for entry in "$search_dir"*
do
	if  [ $entry == "lib" ]
		then
			echo "not that one"
		else
			 echo "that "$entry
			 getfilename "$entry"
			 echo "$somevar"
			 aws lambda update-function-code --function-name "Air3_"$somevar --zip-file "fileb://"$entry
	fi
done

# cd lib

# for entry2 in "$search_dir"*
# do
# 	getfilename "$entry2"
# 	echo "$somevar"
# 	aws lambda update-function-code --function-name "Micro_"$somevar --zip-file "fileb://"$entry2
# done
