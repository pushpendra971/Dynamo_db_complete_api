cd ../../
aws s3 sync air3-backend s3://air3-backend --exclude ".git/*/*/*" 
