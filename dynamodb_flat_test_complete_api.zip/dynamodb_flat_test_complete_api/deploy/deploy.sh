#!/bin/bash
# A sample Bash script, by Ryan

# getfilename(){
# 	entry="$(basename $1)"
# }

getfilename(){
	somevar="$(basename $1)"
}

for entry in "$search_dir"../src/*
do
	echo "$entry"
	if   [ $entry == "../src/lib" ]  
		then
			echo "Dont do anything"
		else
			# echo "asdasd"
			# echo "$entry"
  			getfilename "$entry"
  			echo $entry
  			pwd
  			cd ../src/"$entry"
  			zip -r ../../deploy/src/"$entry".zip *
  			cd ../../deploy
  			pwd
	fi
done

for entry2 in "$search_dir"../src/lib/*
			do
				getfilename "$entry2"
				echo "$somevar"
  				zip -rj ./src/lib/"$somevar".zip ../src/lib/$somevar/*
done


cd ..
cd ..
 # aws s3 sync edare-backend s3://cf-templates-9d1ftuf07ch2-ap-south-1 --exclude "*git/*"
# aws s3 sync talkstyle-backend s3://talkstyle-backend --exclude "*git/*"
