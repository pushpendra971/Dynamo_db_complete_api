///// ...................................... start default setup ............................................////
let mode, docClient, S3;
const AWS = require('aws-sdk');
const response = require('./lib/response.js');
const database = require('./lib/database.js');

if (process.env.AWS_REGION == "local") {
	mode = "offline";
	docClient = require('../../../offline/dynamodb').docClient;
} else {
	mode = "online";
	docClient = new AWS.DynamoDB.DocumentClient({});
}
///// ...................................... end default setup ............................................////

// modules defined here
const Ajv = require('ajv');
const setupAsync = require('ajv-async');
const ajv = setupAsync(new Ajv);

const getSchema = {
	"$async": true,
	"type": "object",
	"additionalProperties": false,
	//"required": ['flat_type', 'building_id'],
	"properties":
	{
		"flat_id": {
			"type": "string"
		},
		"building_id": {
			"type": "string"
		},
		"floor_no": {
			"type": "string"
		},
		"flat_type": {
			"type": "string",
			"enum": [
				"1-BHK",
				"2-BHK",
				"3-BHK",
				"4-BHK"
			]
		},
		"flat_status": {
			"type": "string",
			"enum": [
				"available",
				"reserved",
				"sold"
			]
		},
		"area": {
			"type": "string"
		},
		"price_per_square": {
			"type": "string"
		},
		"total_price": {
			"type": "string",
			"enum": ["true", "false"]

		},
		"features": {
			"type": "string"
		},
		"limit": {
			"type": "string"
		}
	}
};
const validate = ajv.compile(getSchema);

module.exports = { execute };

/**
 * This is the Promise caller which will call each and every function based
 * @param  {[type]}   data     [content to manipulate the data]
 * @param  {Function} callback [need to send response with]
 * @return {[type]}            [description]
 */


function execute(data, callback) {
	validate_all(validate, data)
		.then(function (result) {
			return getFlats(result);
		})
		.then(function (result) {
			response({ code: 200, body: result }, callback);
		})
		.catch(function (err) {
			response({ code: 400, err: { err } }, callback);
		})
}

/**
 * validate the data to the categories
 * @param  {[type]} data [description]
 * @return {[type]}      [description]
 */
function validate_all(validate, data) {
	return new Promise((resolve, reject) => {
		validate(data).then(function (res) {
			console.log(res);
			resolve(res);
		}).catch(function (err) {
			console.log(JSON.stringify(err, null, 6));
			reject(err.errors[0].dataPath + " " + err.errors[0].message);
		})
	})
}

function getFlats(data) {
	console.log(database);
	var params = {
		TableName: database.Table[0].TableName
	};
	if (data.building_id) {
		params["KeyConditionExpression"] = "#building_id = :building_id";
		params["ExpressionAttributeValues"] = { ":building_id": data.building_id };
		params["ExpressionAttributeNames"] = { "#building_id": "building_id" };
		if (data.floor_no) {
			if (params['FilterExpression'] == undefined) {
				params['FilterExpression'] = "";
			}
			params["FilterExpression"] += "#floor_no IN (:floor_no)";
			params["ExpressionAttributeValues"][":floor_no"] = data.floor_no;
			params["ExpressionAttributeNames"]["#floor_no"] = "floor_no";
		}
		if (data.flat_type) {
			if (params['FilterExpression'] == undefined) {
				params['FilterExpression'] = "";
			} else {
				params['FilterExpression'] += " and ";
			}
			params["FilterExpression"] += " #flat_type =(:flat_type)";
			params["ExpressionAttributeValues"][":flat_type"] = data.flat_type;
			params["ExpressionAttributeNames"]["#flat_type"] = "flat_type";
		}
		if (data.flat_status) {
			if (params['FilterExpression'] == undefined) {
				params['FilterExpression'] = "";
			}
			else {
				params['FilterExpression'] += " and ";
			}
			params["FilterExpression"] += " #flat_status =(:flat_status)";
			params["ExpressionAttributeValues"][":flat_status"] = data.flat_status;
			params["ExpressionAttributeNames"]["#flat_status"] = "flat_status";
		}
		if (data.features) {
			if (params['FilterExpression'] == undefined) {
				params['FilterExpression'] = "";
			}
			else {
				params['FilterExpression'] += " and ";
			}
			params["FilterExpression"] += "contains(#features,:features)";
			params["ExpressionAttributeValues"][":features"] = data.features;
			params["ExpressionAttributeNames"]["#features"] = "features";
		}
		if (data.total_price == "true") {
			params['ScanIndexForward'] = true;
		} else {
			params['ScanIndexForward'] = false;
		}
		params['Limit'] = data.limit;
		return new Promise((resolve, reject) => {
			console.log("get_data", params);
			docClient.query(params, function (err, data) {
				console.log(data);
				if (err) reject(err.message) // an error occurred
				else resolve(data);           // successful response
			});
		})
	} else{
		//scan
		if(data.floor_no || data.flat_type || data.features || data.flat_status ){
		  params['ExpressionAttributeValues']={};
		  params['ExpressionAttributeNames']= {};
		}
		if(data.floor_no){
		  if(params['FilterExpression'] == undefined){
			params['FilterExpression'] = "";
		  }
		  params['FilterExpression'] += "#floor_no IN (:floor_no) "
		  params['ExpressionAttributeValues'][":floor_no"] = data.floor_no;
		  params['ExpressionAttributeNames']["#floor_no"] = "floor_no";
		}
		if(data.flat_type){
		  if(params['FilterExpression'] == undefined){
			params['FilterExpression'] = "";
		  }
		  params['FilterExpression'] += "#flat_type IN (:flat_type) "
		  params['ExpressionAttributeValues'][":flat_type"] = data.flat_type;
		  params['ExpressionAttributeNames']["#flat_type"] = "flat_type";
		}
		if(data.features){
		  if(params['FilterExpression'] == undefined){
			params['FilterExpression'] = ""
		  }else{
			params['FilterExpression'] += " and ";
		  }
		  params['FilterExpression'] += "contains(#features,:features)"
		  params['ExpressionAttributeNames']["#features"] = "features";
		  params['ExpressionAttributeValues'][":features"] = data.features;
		}
		if(data.flat_status){
			if(params['FilterExpression'] == undefined){
			  params['FilterExpression'] = "";
			}
			params['FilterExpression'] += "#flat_status IN (:flat_status) "
			params['ExpressionAttributeValues'][":flat_status"] = data.flat_status;
			params['ExpressionAttributeNames']["#flat_status"] = "flat_status";
		  }
		params['Limit'] = data.limit;

		console.log(params,"scan");

		return new Promise((resolve,reject)=>{
		  docClient.scan(params, function(err, data) {
			if(err){
			  reject(err);
			}
			  resolve(data);

		  });
		})
	}		
}

