var AWS = require("aws-sdk");
var fs = require('fs');
AWS.config.update({
region: "ap-south-1",
endpoint: "http://localhost:8000"
});
var docClient = new AWS.DynamoDB.DocumentClient();
console.log("Importing flatss into DynamoDB. Please wait.");
var allFlats = JSON.parse(fs.readFileSync('flats.json', 'utf8'));
allFlats.forEach(function(flat) {
var params = {
TableName: "flat",
Item: {
"flat_id": flat.flat_id,
"building_id": flat.building_id,
"floor_no": flat.floor_no,
"flat_type":flat.flat_type,
"flat_status":flat.flat_status,
"features":flat.features,
"area":flat.area,
"price_per_squre":flat.price_per_squre,
"total_price":flat.total_price
}
};
docClient.put(params, function(err, data) {
if (err) {
console.error("Unable to add flat", flat.flat_id, ". Error JSON:",
JSON.stringify(err, null, 2));
} else {
console.log("PutItem succeeded:", flat.flat_id);
}
});
});