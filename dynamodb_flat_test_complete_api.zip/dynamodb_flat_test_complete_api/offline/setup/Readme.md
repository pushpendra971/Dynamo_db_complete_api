## This Folder is used to setup inital phase of the code for the developer ##
### dynamodb ###

This contains to create a table which will create table and muliple queries in it to set up the db environment
